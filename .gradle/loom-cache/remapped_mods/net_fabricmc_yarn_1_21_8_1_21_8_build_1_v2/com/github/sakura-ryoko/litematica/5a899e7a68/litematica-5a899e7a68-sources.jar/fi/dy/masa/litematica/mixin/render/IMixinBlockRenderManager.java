package fi.dy.masa.litematica.mixin.render;

import net.minecraft.class_756;
import net.minecraft.client.render.block.BlockRenderManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(BlockRenderManager.class)
public interface IMixinBlockRenderManager
{
    @Accessor("builtinModelItemRenderer")
    class_756 litematica_getBuiltinRenderer();
}
