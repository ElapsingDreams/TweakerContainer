package fi.dy.masa.litematica.mixin.render;

import javax.annotation.Nullable;
import net.minecraft.class_806;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.item.property.numeric.NumericProperty;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(class_806.class)
public abstract class MixinModelOverrideList
{
    @SuppressWarnings("deprecation")
    @Redirect(method = "apply", at = @At(value = "INVOKE",
              target = "Lnet/minecraft/client/item/ModelPredicateProvider;call(" +
                       "Lnet/minecraft/item/ItemStack;Lnet/minecraft/client/world/ClientWorld;" +
                       "Lnet/minecraft/entity/LivingEntity;I)F"))
    private float fixCrashWithNullWorld(NumericProperty provider,
                                        ItemStack stack,
                                        @Nullable ClientWorld world,
                                        @Nullable LivingEntity entity,
                                        int i)
    {
        if (world == null)
        {
            return provider.call(stack, MinecraftClient.getInstance().world, entity, i);
        }

        return provider.call(stack, world, entity, i);
    }
}
