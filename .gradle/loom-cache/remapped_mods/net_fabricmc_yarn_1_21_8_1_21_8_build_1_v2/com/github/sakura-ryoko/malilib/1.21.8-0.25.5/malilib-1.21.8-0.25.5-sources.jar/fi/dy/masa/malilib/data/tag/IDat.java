package fi.dy.masa.malilib.data.tag;

import net.minecraft.nbt.NbtElement;
import org.jetbrains.annotations.ApiStatus;

@ApiStatus.Experimental
public interface IDat<T>
{
    T getValue();
    void setValue(T newValue);
    DatType getType();
	NbtElement toVanilla();
}
