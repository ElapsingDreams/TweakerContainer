package fi.dy.masa.malilib.mixin.entity;

import net.minecraft.class_4059;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_4059.class)
public interface IMixinAnimalArmorItem
{
	@Accessor("type")
	class_4059.class_9076 malilib_getAnimalArmorType();
}
