package net.minecraft.client.render.item.model.special;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.ImmutableMap.Builder;
import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import java.util.HashMap;
import java.util.Map;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.block.WoodType;
import net.minecraft.block.SkullBlock.Type;
import net.minecraft.client.render.block.entity.ChestBlockEntityRenderer;
import net.minecraft.client.render.entity.model.LoadedEntityModels;
import net.minecraft.client.render.item.model.special.SpecialModelRenderer.Unbaked;
import net.minecraft.util.DyeColor;
import net.minecraft.util.Identifier;
import net.minecraft.util.dynamic.Codecs.IdMapper;

@Environment(EnvType.CLIENT)
public class SpecialModelTypes {
	public static final IdMapper<Identifier, MapCodec<? extends Unbaked>> ID_MAPPER = new IdMapper();
	public static final Codec<Unbaked> CODEC = ID_MAPPER.getCodec(Identifier.CODEC).dispatch(Unbaked::getCodec, codec -> codec);
	private static final Map<Block, Unbaked> BLOCK_TO_MODEL_TYPE = ImmutableMap.<Block, Unbaked>builder()
		.put(Blocks.SKELETON_SKULL, new net.minecraft.client.render.item.model.special.HeadModelRenderer.Unbaked(Type.SKELETON))
		.put(Blocks.ZOMBIE_HEAD, new net.minecraft.client.render.item.model.special.HeadModelRenderer.Unbaked(Type.ZOMBIE))
		.put(Blocks.CREEPER_HEAD, new net.minecraft.client.render.item.model.special.HeadModelRenderer.Unbaked(Type.CREEPER))
		.put(Blocks.DRAGON_HEAD, new net.minecraft.client.render.item.model.special.HeadModelRenderer.Unbaked(Type.DRAGON))
		.put(Blocks.PIGLIN_HEAD, new net.minecraft.client.render.item.model.special.HeadModelRenderer.Unbaked(Type.PIGLIN))
		.put(Blocks.PLAYER_HEAD, new net.minecraft.client.render.item.model.special.PlayerHeadModelRenderer.Unbaked())
		.put(Blocks.WITHER_SKELETON_SKULL, new net.minecraft.client.render.item.model.special.HeadModelRenderer.Unbaked(Type.WITHER_SKELETON))
		.put(Blocks.SKELETON_WALL_SKULL, new net.minecraft.client.render.item.model.special.HeadModelRenderer.Unbaked(Type.SKELETON))
		.put(Blocks.ZOMBIE_WALL_HEAD, new net.minecraft.client.render.item.model.special.HeadModelRenderer.Unbaked(Type.ZOMBIE))
		.put(Blocks.CREEPER_WALL_HEAD, new net.minecraft.client.render.item.model.special.HeadModelRenderer.Unbaked(Type.CREEPER))
		.put(Blocks.DRAGON_WALL_HEAD, new net.minecraft.client.render.item.model.special.HeadModelRenderer.Unbaked(Type.DRAGON))
		.put(Blocks.PIGLIN_WALL_HEAD, new net.minecraft.client.render.item.model.special.HeadModelRenderer.Unbaked(Type.PIGLIN))
		.put(Blocks.PLAYER_WALL_HEAD, new net.minecraft.client.render.item.model.special.PlayerHeadModelRenderer.Unbaked())
		.put(Blocks.WITHER_SKELETON_WALL_SKULL, new net.minecraft.client.render.item.model.special.HeadModelRenderer.Unbaked(Type.WITHER_SKELETON))
		.put(Blocks.WHITE_BANNER, new net.minecraft.client.render.item.model.special.BannerModelRenderer.Unbaked(DyeColor.WHITE))
		.put(Blocks.ORANGE_BANNER, new net.minecraft.client.render.item.model.special.BannerModelRenderer.Unbaked(DyeColor.ORANGE))
		.put(Blocks.MAGENTA_BANNER, new net.minecraft.client.render.item.model.special.BannerModelRenderer.Unbaked(DyeColor.MAGENTA))
		.put(Blocks.LIGHT_BLUE_BANNER, new net.minecraft.client.render.item.model.special.BannerModelRenderer.Unbaked(DyeColor.LIGHT_BLUE))
		.put(Blocks.YELLOW_BANNER, new net.minecraft.client.render.item.model.special.BannerModelRenderer.Unbaked(DyeColor.YELLOW))
		.put(Blocks.LIME_BANNER, new net.minecraft.client.render.item.model.special.BannerModelRenderer.Unbaked(DyeColor.LIME))
		.put(Blocks.PINK_BANNER, new net.minecraft.client.render.item.model.special.BannerModelRenderer.Unbaked(DyeColor.PINK))
		.put(Blocks.GRAY_BANNER, new net.minecraft.client.render.item.model.special.BannerModelRenderer.Unbaked(DyeColor.GRAY))
		.put(Blocks.LIGHT_GRAY_BANNER, new net.minecraft.client.render.item.model.special.BannerModelRenderer.Unbaked(DyeColor.LIGHT_GRAY))
		.put(Blocks.CYAN_BANNER, new net.minecraft.client.render.item.model.special.BannerModelRenderer.Unbaked(DyeColor.CYAN))
		.put(Blocks.PURPLE_BANNER, new net.minecraft.client.render.item.model.special.BannerModelRenderer.Unbaked(DyeColor.PURPLE))
		.put(Blocks.BLUE_BANNER, new net.minecraft.client.render.item.model.special.BannerModelRenderer.Unbaked(DyeColor.BLUE))
		.put(Blocks.BROWN_BANNER, new net.minecraft.client.render.item.model.special.BannerModelRenderer.Unbaked(DyeColor.BROWN))
		.put(Blocks.GREEN_BANNER, new net.minecraft.client.render.item.model.special.BannerModelRenderer.Unbaked(DyeColor.GREEN))
		.put(Blocks.RED_BANNER, new net.minecraft.client.render.item.model.special.BannerModelRenderer.Unbaked(DyeColor.RED))
		.put(Blocks.BLACK_BANNER, new net.minecraft.client.render.item.model.special.BannerModelRenderer.Unbaked(DyeColor.BLACK))
		.put(Blocks.WHITE_WALL_BANNER, new net.minecraft.client.render.item.model.special.BannerModelRenderer.Unbaked(DyeColor.WHITE))
		.put(Blocks.ORANGE_WALL_BANNER, new net.minecraft.client.render.item.model.special.BannerModelRenderer.Unbaked(DyeColor.ORANGE))
		.put(Blocks.MAGENTA_WALL_BANNER, new net.minecraft.client.render.item.model.special.BannerModelRenderer.Unbaked(DyeColor.MAGENTA))
		.put(Blocks.LIGHT_BLUE_WALL_BANNER, new net.minecraft.client.render.item.model.special.BannerModelRenderer.Unbaked(DyeColor.LIGHT_BLUE))
		.put(Blocks.YELLOW_WALL_BANNER, new net.minecraft.client.render.item.model.special.BannerModelRenderer.Unbaked(DyeColor.YELLOW))
		.put(Blocks.LIME_WALL_BANNER, new net.minecraft.client.render.item.model.special.BannerModelRenderer.Unbaked(DyeColor.LIME))
		.put(Blocks.PINK_WALL_BANNER, new net.minecraft.client.render.item.model.special.BannerModelRenderer.Unbaked(DyeColor.PINK))
		.put(Blocks.GRAY_WALL_BANNER, new net.minecraft.client.render.item.model.special.BannerModelRenderer.Unbaked(DyeColor.GRAY))
		.put(Blocks.LIGHT_GRAY_WALL_BANNER, new net.minecraft.client.render.item.model.special.BannerModelRenderer.Unbaked(DyeColor.LIGHT_GRAY))
		.put(Blocks.CYAN_WALL_BANNER, new net.minecraft.client.render.item.model.special.BannerModelRenderer.Unbaked(DyeColor.CYAN))
		.put(Blocks.PURPLE_WALL_BANNER, new net.minecraft.client.render.item.model.special.BannerModelRenderer.Unbaked(DyeColor.PURPLE))
		.put(Blocks.BLUE_WALL_BANNER, new net.minecraft.client.render.item.model.special.BannerModelRenderer.Unbaked(DyeColor.BLUE))
		.put(Blocks.BROWN_WALL_BANNER, new net.minecraft.client.render.item.model.special.BannerModelRenderer.Unbaked(DyeColor.BROWN))
		.put(Blocks.GREEN_WALL_BANNER, new net.minecraft.client.render.item.model.special.BannerModelRenderer.Unbaked(DyeColor.GREEN))
		.put(Blocks.RED_WALL_BANNER, new net.minecraft.client.render.item.model.special.BannerModelRenderer.Unbaked(DyeColor.RED))
		.put(Blocks.BLACK_WALL_BANNER, new net.minecraft.client.render.item.model.special.BannerModelRenderer.Unbaked(DyeColor.BLACK))
		.put(Blocks.WHITE_BED, new net.minecraft.client.render.item.model.special.BedModelRenderer.Unbaked(DyeColor.WHITE))
		.put(Blocks.ORANGE_BED, new net.minecraft.client.render.item.model.special.BedModelRenderer.Unbaked(DyeColor.ORANGE))
		.put(Blocks.MAGENTA_BED, new net.minecraft.client.render.item.model.special.BedModelRenderer.Unbaked(DyeColor.MAGENTA))
		.put(Blocks.LIGHT_BLUE_BED, new net.minecraft.client.render.item.model.special.BedModelRenderer.Unbaked(DyeColor.LIGHT_BLUE))
		.put(Blocks.YELLOW_BED, new net.minecraft.client.render.item.model.special.BedModelRenderer.Unbaked(DyeColor.YELLOW))
		.put(Blocks.LIME_BED, new net.minecraft.client.render.item.model.special.BedModelRenderer.Unbaked(DyeColor.LIME))
		.put(Blocks.PINK_BED, new net.minecraft.client.render.item.model.special.BedModelRenderer.Unbaked(DyeColor.PINK))
		.put(Blocks.GRAY_BED, new net.minecraft.client.render.item.model.special.BedModelRenderer.Unbaked(DyeColor.GRAY))
		.put(Blocks.LIGHT_GRAY_BED, new net.minecraft.client.render.item.model.special.BedModelRenderer.Unbaked(DyeColor.LIGHT_GRAY))
		.put(Blocks.CYAN_BED, new net.minecraft.client.render.item.model.special.BedModelRenderer.Unbaked(DyeColor.CYAN))
		.put(Blocks.PURPLE_BED, new net.minecraft.client.render.item.model.special.BedModelRenderer.Unbaked(DyeColor.PURPLE))
		.put(Blocks.BLUE_BED, new net.minecraft.client.render.item.model.special.BedModelRenderer.Unbaked(DyeColor.BLUE))
		.put(Blocks.BROWN_BED, new net.minecraft.client.render.item.model.special.BedModelRenderer.Unbaked(DyeColor.BROWN))
		.put(Blocks.GREEN_BED, new net.minecraft.client.render.item.model.special.BedModelRenderer.Unbaked(DyeColor.GREEN))
		.put(Blocks.RED_BED, new net.minecraft.client.render.item.model.special.BedModelRenderer.Unbaked(DyeColor.RED))
		.put(Blocks.BLACK_BED, new net.minecraft.client.render.item.model.special.BedModelRenderer.Unbaked(DyeColor.BLACK))
		.put(Blocks.SHULKER_BOX, new net.minecraft.client.render.item.model.special.ShulkerBoxModelRenderer.Unbaked())
		.put(Blocks.WHITE_SHULKER_BOX, new net.minecraft.client.render.item.model.special.ShulkerBoxModelRenderer.Unbaked(DyeColor.WHITE))
		.put(Blocks.ORANGE_SHULKER_BOX, new net.minecraft.client.render.item.model.special.ShulkerBoxModelRenderer.Unbaked(DyeColor.ORANGE))
		.put(Blocks.MAGENTA_SHULKER_BOX, new net.minecraft.client.render.item.model.special.ShulkerBoxModelRenderer.Unbaked(DyeColor.MAGENTA))
		.put(Blocks.LIGHT_BLUE_SHULKER_BOX, new net.minecraft.client.render.item.model.special.ShulkerBoxModelRenderer.Unbaked(DyeColor.LIGHT_BLUE))
		.put(Blocks.YELLOW_SHULKER_BOX, new net.minecraft.client.render.item.model.special.ShulkerBoxModelRenderer.Unbaked(DyeColor.YELLOW))
		.put(Blocks.LIME_SHULKER_BOX, new net.minecraft.client.render.item.model.special.ShulkerBoxModelRenderer.Unbaked(DyeColor.LIME))
		.put(Blocks.PINK_SHULKER_BOX, new net.minecraft.client.render.item.model.special.ShulkerBoxModelRenderer.Unbaked(DyeColor.PINK))
		.put(Blocks.GRAY_SHULKER_BOX, new net.minecraft.client.render.item.model.special.ShulkerBoxModelRenderer.Unbaked(DyeColor.GRAY))
		.put(Blocks.LIGHT_GRAY_SHULKER_BOX, new net.minecraft.client.render.item.model.special.ShulkerBoxModelRenderer.Unbaked(DyeColor.LIGHT_GRAY))
		.put(Blocks.CYAN_SHULKER_BOX, new net.minecraft.client.render.item.model.special.ShulkerBoxModelRenderer.Unbaked(DyeColor.CYAN))
		.put(Blocks.PURPLE_SHULKER_BOX, new net.minecraft.client.render.item.model.special.ShulkerBoxModelRenderer.Unbaked(DyeColor.PURPLE))
		.put(Blocks.BLUE_SHULKER_BOX, new net.minecraft.client.render.item.model.special.ShulkerBoxModelRenderer.Unbaked(DyeColor.BLUE))
		.put(Blocks.BROWN_SHULKER_BOX, new net.minecraft.client.render.item.model.special.ShulkerBoxModelRenderer.Unbaked(DyeColor.BROWN))
		.put(Blocks.GREEN_SHULKER_BOX, new net.minecraft.client.render.item.model.special.ShulkerBoxModelRenderer.Unbaked(DyeColor.GREEN))
		.put(Blocks.RED_SHULKER_BOX, new net.minecraft.client.render.item.model.special.ShulkerBoxModelRenderer.Unbaked(DyeColor.RED))
		.put(Blocks.BLACK_SHULKER_BOX, new net.minecraft.client.render.item.model.special.ShulkerBoxModelRenderer.Unbaked(DyeColor.BLACK))
		.put(Blocks.OAK_SIGN, new net.minecraft.client.render.item.model.special.SignModelRenderer.Unbaked(WoodType.OAK))
		.put(Blocks.SPRUCE_SIGN, new net.minecraft.client.render.item.model.special.SignModelRenderer.Unbaked(WoodType.SPRUCE))
		.put(Blocks.BIRCH_SIGN, new net.minecraft.client.render.item.model.special.SignModelRenderer.Unbaked(WoodType.BIRCH))
		.put(Blocks.ACACIA_SIGN, new net.minecraft.client.render.item.model.special.SignModelRenderer.Unbaked(WoodType.ACACIA))
		.put(Blocks.CHERRY_SIGN, new net.minecraft.client.render.item.model.special.SignModelRenderer.Unbaked(WoodType.CHERRY))
		.put(Blocks.JUNGLE_SIGN, new net.minecraft.client.render.item.model.special.SignModelRenderer.Unbaked(WoodType.JUNGLE))
		.put(Blocks.DARK_OAK_SIGN, new net.minecraft.client.render.item.model.special.SignModelRenderer.Unbaked(WoodType.DARK_OAK))
		.put(Blocks.PALE_OAK_SIGN, new net.minecraft.client.render.item.model.special.SignModelRenderer.Unbaked(WoodType.PALE_OAK))
		.put(Blocks.MANGROVE_SIGN, new net.minecraft.client.render.item.model.special.SignModelRenderer.Unbaked(WoodType.MANGROVE))
		.put(Blocks.BAMBOO_SIGN, new net.minecraft.client.render.item.model.special.SignModelRenderer.Unbaked(WoodType.BAMBOO))
		.put(Blocks.CRIMSON_SIGN, new net.minecraft.client.render.item.model.special.SignModelRenderer.Unbaked(WoodType.CRIMSON))
		.put(Blocks.WARPED_SIGN, new net.minecraft.client.render.item.model.special.SignModelRenderer.Unbaked(WoodType.WARPED))
		.put(Blocks.OAK_WALL_SIGN, new net.minecraft.client.render.item.model.special.SignModelRenderer.Unbaked(WoodType.OAK))
		.put(Blocks.SPRUCE_WALL_SIGN, new net.minecraft.client.render.item.model.special.SignModelRenderer.Unbaked(WoodType.SPRUCE))
		.put(Blocks.BIRCH_WALL_SIGN, new net.minecraft.client.render.item.model.special.SignModelRenderer.Unbaked(WoodType.BIRCH))
		.put(Blocks.ACACIA_WALL_SIGN, new net.minecraft.client.render.item.model.special.SignModelRenderer.Unbaked(WoodType.ACACIA))
		.put(Blocks.CHERRY_WALL_SIGN, new net.minecraft.client.render.item.model.special.SignModelRenderer.Unbaked(WoodType.CHERRY))
		.put(Blocks.JUNGLE_WALL_SIGN, new net.minecraft.client.render.item.model.special.SignModelRenderer.Unbaked(WoodType.JUNGLE))
		.put(Blocks.DARK_OAK_WALL_SIGN, new net.minecraft.client.render.item.model.special.SignModelRenderer.Unbaked(WoodType.DARK_OAK))
		.put(Blocks.PALE_OAK_WALL_SIGN, new net.minecraft.client.render.item.model.special.SignModelRenderer.Unbaked(WoodType.PALE_OAK))
		.put(Blocks.MANGROVE_WALL_SIGN, new net.minecraft.client.render.item.model.special.SignModelRenderer.Unbaked(WoodType.MANGROVE))
		.put(Blocks.BAMBOO_WALL_SIGN, new net.minecraft.client.render.item.model.special.SignModelRenderer.Unbaked(WoodType.BAMBOO))
		.put(Blocks.CRIMSON_WALL_SIGN, new net.minecraft.client.render.item.model.special.SignModelRenderer.Unbaked(WoodType.CRIMSON))
		.put(Blocks.WARPED_WALL_SIGN, new net.minecraft.client.render.item.model.special.SignModelRenderer.Unbaked(WoodType.WARPED))
		.put(Blocks.OAK_HANGING_SIGN, new net.minecraft.client.render.item.model.special.HangingSignModelRenderer.Unbaked(WoodType.OAK))
		.put(Blocks.SPRUCE_HANGING_SIGN, new net.minecraft.client.render.item.model.special.HangingSignModelRenderer.Unbaked(WoodType.SPRUCE))
		.put(Blocks.BIRCH_HANGING_SIGN, new net.minecraft.client.render.item.model.special.HangingSignModelRenderer.Unbaked(WoodType.BIRCH))
		.put(Blocks.ACACIA_HANGING_SIGN, new net.minecraft.client.render.item.model.special.HangingSignModelRenderer.Unbaked(WoodType.ACACIA))
		.put(Blocks.CHERRY_HANGING_SIGN, new net.minecraft.client.render.item.model.special.HangingSignModelRenderer.Unbaked(WoodType.CHERRY))
		.put(Blocks.JUNGLE_HANGING_SIGN, new net.minecraft.client.render.item.model.special.HangingSignModelRenderer.Unbaked(WoodType.JUNGLE))
		.put(Blocks.DARK_OAK_HANGING_SIGN, new net.minecraft.client.render.item.model.special.HangingSignModelRenderer.Unbaked(WoodType.DARK_OAK))
		.put(Blocks.PALE_OAK_HANGING_SIGN, new net.minecraft.client.render.item.model.special.HangingSignModelRenderer.Unbaked(WoodType.PALE_OAK))
		.put(Blocks.MANGROVE_HANGING_SIGN, new net.minecraft.client.render.item.model.special.HangingSignModelRenderer.Unbaked(WoodType.MANGROVE))
		.put(Blocks.BAMBOO_HANGING_SIGN, new net.minecraft.client.render.item.model.special.HangingSignModelRenderer.Unbaked(WoodType.BAMBOO))
		.put(Blocks.CRIMSON_HANGING_SIGN, new net.minecraft.client.render.item.model.special.HangingSignModelRenderer.Unbaked(WoodType.CRIMSON))
		.put(Blocks.WARPED_HANGING_SIGN, new net.minecraft.client.render.item.model.special.HangingSignModelRenderer.Unbaked(WoodType.WARPED))
		.put(Blocks.OAK_WALL_HANGING_SIGN, new net.minecraft.client.render.item.model.special.HangingSignModelRenderer.Unbaked(WoodType.OAK))
		.put(Blocks.SPRUCE_WALL_HANGING_SIGN, new net.minecraft.client.render.item.model.special.HangingSignModelRenderer.Unbaked(WoodType.SPRUCE))
		.put(Blocks.BIRCH_WALL_HANGING_SIGN, new net.minecraft.client.render.item.model.special.HangingSignModelRenderer.Unbaked(WoodType.BIRCH))
		.put(Blocks.ACACIA_WALL_HANGING_SIGN, new net.minecraft.client.render.item.model.special.HangingSignModelRenderer.Unbaked(WoodType.ACACIA))
		.put(Blocks.CHERRY_WALL_HANGING_SIGN, new net.minecraft.client.render.item.model.special.HangingSignModelRenderer.Unbaked(WoodType.CHERRY))
		.put(Blocks.JUNGLE_WALL_HANGING_SIGN, new net.minecraft.client.render.item.model.special.HangingSignModelRenderer.Unbaked(WoodType.JUNGLE))
		.put(Blocks.DARK_OAK_WALL_HANGING_SIGN, new net.minecraft.client.render.item.model.special.HangingSignModelRenderer.Unbaked(WoodType.DARK_OAK))
		.put(Blocks.PALE_OAK_WALL_HANGING_SIGN, new net.minecraft.client.render.item.model.special.HangingSignModelRenderer.Unbaked(WoodType.PALE_OAK))
		.put(Blocks.MANGROVE_WALL_HANGING_SIGN, new net.minecraft.client.render.item.model.special.HangingSignModelRenderer.Unbaked(WoodType.MANGROVE))
		.put(Blocks.BAMBOO_WALL_HANGING_SIGN, new net.minecraft.client.render.item.model.special.HangingSignModelRenderer.Unbaked(WoodType.BAMBOO))
		.put(Blocks.CRIMSON_WALL_HANGING_SIGN, new net.minecraft.client.render.item.model.special.HangingSignModelRenderer.Unbaked(WoodType.CRIMSON))
		.put(Blocks.WARPED_WALL_HANGING_SIGN, new net.minecraft.client.render.item.model.special.HangingSignModelRenderer.Unbaked(WoodType.WARPED))
		.put(Blocks.CONDUIT, new net.minecraft.client.render.item.model.special.ConduitModelRenderer.Unbaked())
		.put(Blocks.CHEST, new net.minecraft.client.render.item.model.special.ChestModelRenderer.Unbaked(ChestModelRenderer.NORMAL_ID))
		.put(Blocks.TRAPPED_CHEST, new net.minecraft.client.render.item.model.special.ChestModelRenderer.Unbaked(ChestModelRenderer.TRAPPED_ID))
		.put(Blocks.ENDER_CHEST, new net.minecraft.client.render.item.model.special.ChestModelRenderer.Unbaked(ChestModelRenderer.ENDER_ID))
		.put(Blocks.DECORATED_POT, new net.minecraft.client.render.item.model.special.DecoratedPotModelRenderer.Unbaked())
		.build();
	private static final net.minecraft.client.render.item.model.special.ChestModelRenderer.Unbaked CHRISTMAS_CHEST = new net.minecraft.client.render.item.model.special.ChestModelRenderer.Unbaked(
		ChestModelRenderer.CHRISTMAS_ID
	);

	public static void bootstrap() {
		ID_MAPPER.put(Identifier.ofVanilla("bed"), net.minecraft.client.render.item.model.special.BedModelRenderer.Unbaked.CODEC);
		ID_MAPPER.put(Identifier.ofVanilla("banner"), net.minecraft.client.render.item.model.special.BannerModelRenderer.Unbaked.CODEC);
		ID_MAPPER.put(Identifier.ofVanilla("conduit"), net.minecraft.client.render.item.model.special.ConduitModelRenderer.Unbaked.CODEC);
		ID_MAPPER.put(Identifier.ofVanilla("chest"), net.minecraft.client.render.item.model.special.ChestModelRenderer.Unbaked.CODEC);
		ID_MAPPER.put(Identifier.ofVanilla("head"), net.minecraft.client.render.item.model.special.HeadModelRenderer.Unbaked.CODEC);
		ID_MAPPER.put(Identifier.ofVanilla("player_head"), net.minecraft.client.render.item.model.special.PlayerHeadModelRenderer.Unbaked.CODEC);
		ID_MAPPER.put(Identifier.ofVanilla("shulker_box"), net.minecraft.client.render.item.model.special.ShulkerBoxModelRenderer.Unbaked.CODEC);
		ID_MAPPER.put(Identifier.ofVanilla("shield"), net.minecraft.client.render.item.model.special.ShieldModelRenderer.Unbaked.CODEC);
		ID_MAPPER.put(Identifier.ofVanilla("trident"), net.minecraft.client.render.item.model.special.TridentModelRenderer.Unbaked.CODEC);
		ID_MAPPER.put(Identifier.ofVanilla("decorated_pot"), net.minecraft.client.render.item.model.special.DecoratedPotModelRenderer.Unbaked.CODEC);
		ID_MAPPER.put(Identifier.ofVanilla("standing_sign"), net.minecraft.client.render.item.model.special.SignModelRenderer.Unbaked.CODEC);
		ID_MAPPER.put(Identifier.ofVanilla("hanging_sign"), net.minecraft.client.render.item.model.special.HangingSignModelRenderer.Unbaked.CODEC);
	}

	public static Map<Block, SpecialModelRenderer<?>> buildBlockToModelTypeMap(LoadedEntityModels entityModels) {
		Map<Block, Unbaked> map = new HashMap(BLOCK_TO_MODEL_TYPE);
		if (ChestBlockEntityRenderer.isAroundChristmas()) {
			map.put(Blocks.CHEST, CHRISTMAS_CHEST);
			map.put(Blocks.TRAPPED_CHEST, CHRISTMAS_CHEST);
		}

		Builder<Block, SpecialModelRenderer<?>> builder = ImmutableMap.builder();
		map.forEach((block, modelType) -> {
			SpecialModelRenderer<?> specialModelRenderer = modelType.bake(entityModels);
			if (specialModelRenderer != null) {
				builder.put(block, specialModelRenderer);
			}
		});
		return builder.build();
	}
}
