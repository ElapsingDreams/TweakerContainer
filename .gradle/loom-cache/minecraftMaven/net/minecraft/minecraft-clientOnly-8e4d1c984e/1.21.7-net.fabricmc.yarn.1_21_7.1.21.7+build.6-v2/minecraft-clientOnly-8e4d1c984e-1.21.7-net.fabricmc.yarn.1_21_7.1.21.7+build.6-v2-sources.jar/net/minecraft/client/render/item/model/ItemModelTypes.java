package net.minecraft.client.render.item.model;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.item.model.ItemModel.Unbaked;
import net.minecraft.util.Identifier;
import net.minecraft.util.dynamic.Codecs.IdMapper;

@Environment(EnvType.CLIENT)
public class ItemModelTypes {
	public static final IdMapper<Identifier, MapCodec<? extends Unbaked>> ID_MAPPER = new IdMapper();
	public static final Codec<Unbaked> CODEC = ID_MAPPER.getCodec(Identifier.CODEC).dispatch(Unbaked::getCodec, codec -> codec);

	public static void bootstrap() {
		ID_MAPPER.put(Identifier.ofVanilla("empty"), net.minecraft.client.render.item.model.EmptyItemModel.Unbaked.CODEC);
		ID_MAPPER.put(Identifier.ofVanilla("model"), net.minecraft.client.render.item.model.BasicItemModel.Unbaked.CODEC);
		ID_MAPPER.put(Identifier.ofVanilla("range_dispatch"), net.minecraft.client.render.item.model.RangeDispatchItemModel.Unbaked.CODEC);
		ID_MAPPER.put(Identifier.ofVanilla("special"), net.minecraft.client.render.item.model.SpecialItemModel.Unbaked.CODEC);
		ID_MAPPER.put(Identifier.ofVanilla("composite"), net.minecraft.client.render.item.model.CompositeItemModel.Unbaked.CODEC);
		ID_MAPPER.put(Identifier.ofVanilla("bundle/selected_item"), net.minecraft.client.render.item.model.BundleSelectedItemModel.Unbaked.CODEC);
		ID_MAPPER.put(Identifier.ofVanilla("select"), net.minecraft.client.render.item.model.SelectItemModel.Unbaked.CODEC);
		ID_MAPPER.put(Identifier.ofVanilla("condition"), net.minecraft.client.render.item.model.ConditionItemModel.Unbaked.CODEC);
	}
}
